UPLOAD_FOLDER = 'app/static/uploads'
